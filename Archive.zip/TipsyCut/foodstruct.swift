import Foundation

// 🌟 백엔드 JSON 형식과 완벽하게 일치하도록 수정된 데이터 모델
struct DietLog: Identifiable, Codable {
    // Identifiable 프로토콜을 위한 id (MongoDB의 _id를 매핑하거나, 없다면 UUID 생성)
    var id: String { _id ?? UUID().uuidString }
    
    // 백엔드에서 내려주는 실제 데이터 필드들 (카멜 케이스 & 타입 일치)
    var _id: String?          // MongoDB가 만들어주는 고유 ID
    var userId: String        // String 타입으로 변경 (예: "6a2f8b0b...")
    var mealType: String      // "아침", "점심", "저녁" 등
    var foodName: String
    var amount: Double        // String -> Double 로 변경 (예: 1.0, 250.0)
    var calories: Double      // calorie -> calories 로 이름 변경
    var carbs: Double         // carb -> carbs 로 이름 변경
    var protein: Double
    var fat: Double
    var imageUrl: String?
    var eatenAt: String       // "2026-06-15T12:30:00" 형태
    var createdAt: String?
    var unit: String?         // amount의 단위: "g"(사진 분석), "인분"(추천 메뉴), "병/캔"(술). 예전 기록은 nil
    
    // 💡 서버는 기록의 고유 ID를 "id"로 내려주므로, 앱의 _id와 연결해 줍니다.
    enum CodingKeys: String, CodingKey {
        case _id = "id"
        case userId, mealType, foodName, amount, calories, carbs, protein, fat
        case imageUrl, eatenAt, createdAt, unit
    }
    
    // 수량 표시용 문자열 (예: 250g, 1.5인분, 2잔) — unit이 없는 예전 기록은 g로 간주
    var amountText: String {
        let value = amount.truncatingRemainder(dividingBy: 1) == 0
            ? String(Int(amount))
            : String(format: "%g", amount)
        return "\(value)\(unit ?? "g")"
    }
    
    // 1인분 기준 데이터를 servings 인분으로 환산한 복사본 (칼로리·탄단지 비례 계산)
    func scaled(by servings: Double) -> DietLog {
        var copy = self
        copy.amount = servings
        copy.unit = "인분"
        copy.calories = calories * servings
        copy.carbs = carbs * servings
        copy.protein = protein * servings
        copy.fat = fat * servings
        return copy
    }
    
    // UI 프로그래스 바를 위한 연산 프로퍼티
    var carbRatio: Double { min(carbs / 150.0, 1.0) }
    var proteinRatio: Double { min(protein / 75.0, 1.0) }
    var fatRatio: Double { min(fat / 50.0, 1.0) }
}

// 🌟 텍스트 검색 API(Spoonacular) 결과를 받기 위한 전용 구조체 추가
struct FoodSearchResult: Codable, Identifiable {
    var id: String { foodName }   // 💡 매번 새 UUID가 만들어지면 선택 표시가 사라져서 이름으로 고정
    let foodName: String
    let imageUrl: String?
    let calories: Double
    let carbs: Double
    let protein: Double
    let fat: Double
    var source: String? = nil        // "내 메뉴", "식약처" 등 출처 표시용 (없으면 표시 안 함)
    var servingNote: String? = nil   // 1인분 기준 안내 (예: "1인분 = 270g (식약처 기준)")
}

// 💡 파이썬 서버의 최종 AI 분석 결과를 매핑하기 위한 모델
struct AIAnalysisResponse: Codable {
    let status: String
    let spoonDetected: Bool?
    let results: [AIArticleResult]
}

struct AIArticleResult: Codable, Hashable {
    let foodName: String
    let weightG: Double
    let caloriesKcal: Double
    let shapeType: String
    // 💡 [추가] 서버가 계산한 탄수화물·단백질·지방(g). 서버 응답(carbs_g 등)이 없으면 nil
    let carbsG: Double?
    let proteinG: Double?
    let fatG: Double?
    // 💡 [추가] 서버가 "숟가락 미인식 -> 기본값 추정"일 때 보내는 안내 문구.
    // 정상적으로 정밀 계산됐을 땐 서버 응답에 이 키 자체가 없으므로 옵셔널로 둠.
    let message: String?
}
